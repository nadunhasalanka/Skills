---
name: story-reel-writer
description: Transforms a raw story, post, or another video's script into an original narrated "strange true story" reel package — narrator script, scene-by-scene visual breakdown, and a caption. Activate ONLY when the user explicitly invokes it — e.g. types "run story reel writer", "use the story reel writer", or directly asks to run this skill. Do NOT auto-trigger just because the user pastes a story, article, or transcript. This runs on explicit invocation only.
---

# Story Reel Writer

This skill turns a raw input (a post, an article, or another video's script) into an original narrated reel package in the "strange true stories" style — calm, factual, documentary tone with an undercurrent of quiet dread, ending on a haunting line that lingers.

## The voice (never changes)

Every output uses ONE consistent tone, regardless of story sub-type:

- **Calm and factual.** Report events plainly, like a documentary. Do not dramatize with exclamation or hype.
- **Quiet dread underneath.** Let the darkness or strangeness emerge from the facts themselves, not from emotional language.
- **Escalating intrigue.** Stay calm but let the facts build tension as the story progresses.
- **Haunting quiet ending.** Always end on a final line that lands heavy and lingers. NEVER end with a question or an engagement prompt like "what would you do?". The weight does the work.

**Opening rule:**
- If the story has a clear date or year, OPEN with it: "In 1997…", "In 1689…". The date grounds the viewer immediately.
- If there is no clear date, open with a HOOK instead — a striking fact, contradiction, or question-like statement that creates instant curiosity (e.g. "Britain's most trusted family doctor was actually history's deadliest serial killer.").

Sub-types the skill recognizes — dark history, true crime, unsolved mystery, eerie coincidence, forgotten origin. The sub-type may affect which details to emphasize and how to frame the hook, but **the tone never changes.**

## Hard rules

- **Never change story facts.** Names, places, dates, outcomes, and events must stay exactly true to the source. Originality comes ONLY from rewording and restructuring the language — never from altering what happened.
- **For fictional or unverified input**, work only with what the user pasted. Do no outside research.
- **For true stories with links/extra text**, research to ADD missing context or find more interesting true angles — never to change the established facts.
- **Endings never ask questions.** Always a quiet, lingering final line.

## Step-by-step workflow

Run this interactively, one step at a time. Do not jump ahead.

**Step 1 — Receive the input.** The user pastes a story, post, or script. Acknowledge it briefly.

**Step 2 — Ask if it's true or fictional.**
Ask: "Is this a true story, or fictional/unverified?"

**Step 3 — If true, ask for research material.**
Ask: "Do you have any links or extra text you'd like me to follow and research for added context? Or should I research it myself / work with what's here?"
- If links/text are given, research to add missing context or surface more interesting true details. Never alter core facts.
- If fictional/unverified, skip research entirely.

**Step 4 — Suggest a length and confirm.**
Based on the richness of the story, suggest an appropriate length (e.g., "This one has enough for about 45 seconds — how long would you like it?"). Wait for the user to confirm the length before writing.

**Step 5 — Ask caption length.**
Ask: "How long would you like the caption?" (The caption is always the longer, human-sounding style — confirm how long.)

**Step 6 — Produce the full output** (see Output Format below).

## Output format

Produce three parts, in this order:

### 1. NARRATOR SCRIPT
The full flowing narration as one clean continuous piece, ready to paste straight into a voice tool (e.g., ElevenLabs). Calm documentary tone, opens with a hook (a question, contradiction, or striking fact), builds with escalating true detail, hits a twist or reveal, and ends on a haunting quiet line.

### 2. SCENE BREAKDOWN
Divide the same script into scenes for visuals.
- **At least 5 scenes per 30 seconds**, scaling proportionally (~1 scene per 6 seconds). A 60s video = at least 10 scenes. Adjust scene count to fit the story's natural beats.
- For each scene provide:
  - **Scene number**
  - **Narration:** the exact portion of the script that plays over this scene
  - **Visual suggestion:** a short, concrete hint of what image or shot to create (setting, subject, mood, framing)

Format each scene like:
```
Scene 1
Narration: "..."
Visual: ...
```

### 3. CAPTION
A longer, human-sounding caption in the SAME calm tone as the script. It should read like a person wrote it, not marketing copy. Match the length the user requested in Step 5. Do not end the caption with an engagement question either — keep the voice consistent.

## Length guide

| Video length | Approx. word count | Minimum scenes |
|---|---|---|
| 30s | ~70–80 words | 5 |
| 45s | ~105–120 words | 8 |
| 60s | ~140–160 words | 10 |
| 90s | ~210–240 words | 15 |

Narration pacing is roughly 2.5 words per second for this calm style. Use this to hit the confirmed length.

## Reference examples of the target voice

Study these to match the tone exactly (calm, factual, escalating, haunting ending — no questions):

**Example (forgotten origin):**
"In 1689, Spanish soldiers pushed into unmapped territory and met the Caddo people. The Caddo had a word for their allies: Taysha. The Spanish wrote it down as Tay-jus and thought it was a place name. It wasn't. It just meant friends. By 1860, the Caddo were gone, removed from the land named after their word for friendship."

**Example (true crime):**
"Did you know Britain's most trusted family doctor was actually history's deadliest serial killer? ... In 2000, he was convicted of 15 murders, though investigators believe he killed over 250 people. His medical authority provided perfect cover for mass murder. Four years later, Shipman cheated justice one final time, hanging himself in his prison cell."

Note how both stay calm, let dark facts speak, and end on a quiet line that lingers — never a question.
