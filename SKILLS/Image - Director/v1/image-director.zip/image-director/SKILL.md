---
name: image-director
description: Multi-stage interactive workflow that turns a story/script into a sequence of static image-generation prompts — one image per 3 seconds of narration — in a single locked visual style with consistent recurring characters. Activate ONLY when the user explicitly types "run image director" or directly asks to run the image director. Do NOT auto-trigger on general image, prompt-writing, or art requests — explicit invocation only.
disable-model-invocation: true
---

# Image Director

A guided workflow for turning a script into an ordered sequence of static images. It locks one visual style and any recurring characters up front, generates the reference images first, then emits one descriptive-prose image prompt per beat — one at a time, the user confirming each before the next.

This skill is self-contained for normal operation — every rule needed to run is below. A companion file, `reference.md`, sits in this same folder with the realism craft, the style-extraction checklist, model notes, and troubleshooting. Read it when a generation looks fake/plastic, a character drifts, or the user wants an unusual style.

---

## ACTIVATION

Run only when explicitly invoked ("run image director"). On activation:
- If the user already gave a script, restate it in one line and go to Stage 1.
- If not, ask for the script/story and the target duration, then go to Stage 1.

Do not emit any image prompt until the style and any recurring characters are locked (Stage 1) and the reference images are issued (Stage 3).

---

## HOW TO RUN — interview discipline (follow strictly)

1. **Ask in grouped rounds, one round per stage.** Present all of a stage's questions together, then STOP and wait. Never drip one question at a time. Never invent answers to skip a stage.
2. **Propose, don't interrogate.** Infer from the script where you can; state your proposal and ask the user to confirm or adjust.
3. **Offer an escape hatch.** End each question round with: *"Or say 'defaults' and I'll make strong choices for the rest."*
4. **Lock and carry forward.** Once style, aspect ratio, and character identities are set, inject them into every prompt verbatim — never make the user restate them.
5. **One image = one beat = ~3 seconds of narration.** Output is descriptive prose, one prompt at a time.

---

## STAGE 1 — Project intake

Read the script. Then ask this grouped round:

- **Duration:** total length in seconds. (Image count = round(duration ÷ 3). State it back: "30s → 10 images.")
- **Aspect ratio:** 16:9, 9:16, or 1:1?
- **Style:** describe the look in words, OR say you'll upload a reference image to match. If a reference image is provided, read it and write a **locked style block** capturing palette, light quality and direction, grain/texture, lens character, mood, and medium/era — this block is reused on every prompt.
- **Recurring characters / key subjects:** name anyone or anything that appears in more than one beat, so their identity can be locked.

Then, **once per session only**, show this compact legend (keep it short; frame as reference, never a quiz; never repeat):

```
Quick legend (so the style choices make sense):
STYLE FAMILY: photography (real-camera look) · cinematic film still · illustration · 3D render · anime · oil/watercolor · retro/vintage
LIGHT/MOOD:   soft natural = gentle · golden hour = warm, emotional · hard contrast = dramatic · overcast = flat, honest · low-key = moody, shadowy
REALISM DIAL (photography only): polished/editorial ←→ candid/amateur/snapshot (more imperfection = reads more real)
```

Wait for answers. Restate the locked **Project Settings** (style block, aspect ratio, image count, character identity blocks) in a short block, then go to Stage 2.

---

## STAGE 2 — Storyboard segmentation

Split the script into N beats, where N = round(duration ÷ 3). Each beat is roughly equal spoken length (~3s, ~7–8 words of narration) and becomes one image. Present the full breakdown:

```
Beat 1 — "[the ~3s line of narration]" → [one-line image concept]
Beat 2 — "[line]" → [concept]
...
```

Ask: "Adjust any beat's split or concept, or confirm and we'll lock the look." Wait. Lock the confirmed breakdown.

---

## STAGE 3 — Reference images FIRST

Before any beat prompt, issue the **reference-image creation prompts** so the look is fixed up front. These are prompts for an image model (e.g. Gemini 2.5 Flash Image / Nano Banana) — this step outputs prompts, not images. The user generates them, then those images anchor every beat.

Issue, as needed:
- **Style anchor** — one prompt that establishes the locked style on a neutral representative subject. (Skip if the style came from an uploaded reference image — that image is already the anchor.)
- **One per recurring character/subject** — role-based, lockable: front-facing or 3/4, neutral expression, plain seamless background, even lighting, full identity features visible, in the locked style.

Lockability rules: plain backgrounds, even consistent lighting, neutral framing, full visibility of identifying features, reuse the SAME references across all beats.

Tell the user to generate these and (optionally) confirm they're happy with the look before Stage 4. The locked style and character identities are now fixed for every beat.

---

## STAGE 4 — Beat-by-beat prompts (one at a time)

Go through the beats in order. For EACH beat, emit ONE descriptive-prose image prompt, then STOP and ask "Adjust this one, or continue to the next?" Only proceed on the user's go.

Each beat prompt must:
- Illustrate that beat's narration line as a single static moment.
- Carry the **locked style block verbatim**.
- Carry the **character identity block verbatim** for any locked character in the beat, and point at their reference ("the character from the reference — [identity]").
- Apply the realism craft below when the style is photographic.
- Match the locked aspect ratio.

Write it as one flowing descriptive paragraph (best for Nano Banana / GPT Image / Gemini), not labeled fields.

---

## STYLE & REALISM RULES

- **One style, everywhere.** The locked style block is pasted into every beat prompt, unchanged. Consistency comes from identical wording, not from re-describing the look each time.
- **Realism (when the style is photographic)** comes from constraint + imperfection, not from "quality" words:
  - Name a real camera and lens behaviour — focal length and aperture for natural depth of field ("50mm, f/1.8, soft background blur"); optionally a film stock for color.
  - Name natural light — window light, golden hour, overcast, a single practical lamp.
  - Add authentic imperfection — skin texture and pores, slight grain, a touch of motion blur, candid (not posed) framing, mild asymmetry; "amateur snapshot" or "disposable camera" for raw realism.
  - **Delete quality-spam** — no "8k, ultra-detailed, hyperrealistic, octane render, masterpiece, trending on artstation." These produce the plastic AI look. Restraint reads as real.
- **Character consistency** is separate from style and harder: lock the identity in words, carry it verbatim, point each beat at the same reference image. Without this, the character changes face/clothes between beats.

---

## OUTPUT SHAPE (each beat)

One descriptive paragraph containing, woven naturally: the locked style → the subject/character (with identity if locked) → the single moment/action → the setting and named light → realism markers (if photographic) → aspect ratio. No labeled fields. No quality-spam.

---

## CLOSING

When all beats are emitted, give a short recap: the locked style, the image count, the list of beats, and which reference images the user still needs to generate. The prompts are the deliverable — don't pad with commentary.
