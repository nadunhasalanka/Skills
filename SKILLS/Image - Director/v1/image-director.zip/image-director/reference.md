# Image Prompting — Reference

The knowledge base for the image-director workflow. Covers realistic image craft, copying a style from an uploaded image, model notes, and fixes. General — any style, any subject.

---

## 1. How realism actually works

Authenticity comes from photographic constraint and deliberate imperfection — and from *removing* "quality" words, not adding them. Over-prompting for quality is what produces the plastic AI look.

A realistic prompt carries:

- **A real camera and lens behaviour** — focal length + aperture drive the depth of field and bokeh the eye reads as "a photo" (e.g. "85mm, f/1.4, shallow focus"). A film stock fixes authentic color (Portra 400, Cinestill 800T, Gold 200).
- **Named natural light** — window light, golden hour, overcast, a single practical lamp. Not "beautiful lighting."
- **Imperfection markers** (the lever almost nobody uses) — skin texture and pores, stray hairs, slight grain, a touch of motion blur, candid (not posed) framing, mild asymmetry, real environmental clutter. "Amateur snapshot" / "disposable camera" pushes maximum realism.
- **Restraint** — DELETE "8k, ultra-detailed, hyperrealistic, octane render, masterpiece, trending on artstation, award-winning." These tags push toward over-sharpened CGI. Less polish reads as more real.

Rule of thumb: describe a real camera in real light with real flaws. The more you reach for "perfect," the more synthetic it looks.

---

## 2. Copying a style from an uploaded image

Two routes:

- **Native style reference** — feed the image into the model directly (Gemini / Nano Banana image input, Midjourney `--sref`). Direct, but model-dependent and inconsistent.
- **Extraction (preferred, model-agnostic)** — read the image and write a reusable **style block** in words. Reusable across any subject and any model, and editable.

When extracting a style from an uploaded image, read and capture:

| Read this | Capture as |
|---|---|
| Color | palette, saturation, white balance, color cast |
| Light | direction, hardness/softness, contrast, time-of-day feel |
| Texture | grain, sharpness, film vs digital, surface feel |
| Lens | focal-length feel, depth of field, distortion, vignetting |
| Composition | framing, symmetry, negative space, perspective |
| Medium/era | photo / illustration / 3D / paint; modern / vintage |
| Mood | the overall emotional tone |

The result is a locked style block you paste into every prompt unchanged.

---

## 3. Style families (quick reference)

photography (real-camera) · cinematic film still · illustration · sketch/line art · 3D render · anime/manga · oil painting · watercolor · ink · retro/vintage · cyberpunk · minimalism. Pick one and lock it for the whole sequence — mixing families across a sequence breaks cohesion.

---

## 4. Model notes

- **Gemini / Nano Banana, GPT Image** — prefer natural descriptive language in full sentences. No parameter spam. Describe the scene like you're briefing a photographer.
- **Midjourney** — supports parameters (`--ar`, `--stylize`, `--sref` for style reference, `--cref` for character reference). Keep the description tight; let params carry style/consistency.
- Across all: one clear subject, one clear light, one clear style. Contradictions between your words and a reference image make the words win or the result drift.

---

## 5. Character consistency across a sequence

Separate problem from style, and harder. Static models drift a character across separate generations.

- Write a fixed **identity block** (age, build, face, hair, distinctive marks, wardrobe) and paste it verbatim into every beat the character appears in.
- Generate ONE clean character reference image first and reuse it (`--cref`, or as an ingredient) across beats.
- Anchor on unchanging details — a jacket, a scar, glasses, hair color.
- Accept the ceiling: separate generations are *consistent*, never identical. For true sameness, edit/inpaint from one base image rather than regenerating.

---

## 6. Worked example — one beat

Brief: beat reads *"she steps off the bus into the rain."* Locked style: muted 90s film photography.

> Muted 90s film photograph, Portra 400 color, soft overcast light. A young woman in a worn olive raincoat steps down from a city bus onto a wet pavement, one hand catching the door rail, eyes down against the drizzle. Grey street, blurred traffic behind, faint reflections on the asphalt. Shot on 35mm, 50mm lens, f/2, gentle grain, slight motion blur on her step, candid and unposed. 16:9.

Note: a real camera, real light, real imperfection, the locked style stated once — and zero "8k / hyperreal / masterpiece."

---

## 7. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Looks fake / plastic / CGI | Quality-spam, no real-camera or light cues | Remove "8k/hyperreal/octane"; add lens + aperture + named light + grain |
| Too clean to be real | No imperfection | Add texture, candid framing, slight blur, "amateur snapshot" |
| Character changes between images | Identity not locked / no reference | Paste identity block verbatim; reuse one character reference |
| Style drifts across the sequence | Style block reworded each time | Paste the identical locked style block every time |
| Uploaded style not matched | Relied on the image alone | Extract the style into words (§2) and include it in the prompt |
| Faces/hands distorted | Over-complex framing | Pull wider; simplify pose; fewer subjects |

---

*This is the knowledge base. A companion director skill turns a script into a locked-style image sequence using everything here.*
