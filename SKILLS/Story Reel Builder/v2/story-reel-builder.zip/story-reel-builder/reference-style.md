# LOCKED VISUAL STYLE — reference

This file is the single source of truth for the page's look. Every image prompt and every
video prompt the skill produces MUST carry this full description woven into the prompt text —
not as a short label, but as dense sensory wording. The richness lives in the words.

## The full style block (inject this richness into EVERY prompt)

Use this exact richness in every scene, adapting only the subject/era:

> rich vivid natural color that feels alive and saturated but realistic — deep, full tones
> (greens, earthy browns, warm skin, deep blues) that never wash out or drain to grey;
> strong atmospheric depth with soft haze, light catching in the air, and layered distance
> that pulls the eye in; a single clear light source shaping the scene; raw, real, authentic
> documentary footage look — unpolished, not glossy, not over-rendered; fine natural film
> grain across the whole frame; shallow depth of field isolating the subject; an immersive,
> curious, story-rich mood

## Critical rules that made the good test images work

1. **Describe the color depth in specific terms**, not just "rich color." Name the actual
   tones present in THIS scene (e.g. "deep forest greens and earthy browns," "warm candle-
   glow oranges against deep shadow"). Specific named tones are what created the richness in
   the approved images.
2. **Always force atmosphere** — haze, mist, light catching in the air, depth. Even bright
   daytime scenes (a football pitch, a stadium, a street at noon) MUST get atmospheric
   treatment, or they render flat and generic. Add "soft atmospheric haze, hazy depth, light
   catching in the air, rich saturated color, fine film grain" to daytime scenes explicitly.
3. **Color must HOLD in the dark.** Night/interior/candlelit scenes keep deep glowing color
   (warm oranges, deep ambers, rich shadow color) — never flatten to grey.
4. **Raw, not glossy.** Use words: raw, real, authentic, documentary, unpolished, film grain.
   Avoid: cinematic, glossy, rendered, polished, CGI, clean.
5. **No on-screen text, ever** — forbid text/captions/words/letters in body AND negatives.

## GOLD-STANDARD example prompts (match this density every time)

These two produced the approved look. Every generated prompt should be this rich.

**Example A — exterior, daylight (soldiers):**
> A group of 18th century European soldiers on horseback riding slowly through a dense
> forest in early morning light, rich natural color with deep greens and earthy browns, soft
> light filtering through the trees creating atmospheric depth and visible haze in the air,
> raw realistic documentary footage look, fine natural film grain, immersive and curious
> mood, weathered authentic uniforms and textures, shallow depth of field drawing focus to
> the lead rider, period accurate to the 1700s with no modern objects, 9:16 vertical.
> Absolutely no text, no captions, no words, no letters anywhere.

**Example B — interior, candlelight (sickbed):**
> A man lying on a simple bed inside a wooden cabin at night, lit by a single candle on a
> nearby table, rich warm and natural color with deep glowing candle-orange against deep
> shadow, the color staying full and alive in the darkness, soft atmospheric haze in the dim
> air, raw realistic documentary footage look with fine film grain, immersive and slightly
> mysterious mood, authentic period furniture and rough fabric textures, shallow depth of
> field, period accurate with no modern objects, 9:16 vertical. Absolutely no text, no
> captions, no words, no letters anywhere.

## The test

Before emitting any prompt, check: does it name specific rich tones for THIS scene? Does it
force haze/atmosphere/depth even if it's daytime? Does it say raw/documentary/film grain, not
glossy/cinematic? Does it forbid all text? If any answer is no, rewrite before output.
