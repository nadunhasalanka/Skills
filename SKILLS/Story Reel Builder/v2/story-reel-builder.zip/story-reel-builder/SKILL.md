---
name: story-reel-builder
description: Multi-stage interactive workflow that turns a "strange true story" narration script (or a ready-made scene breakdown) into structured, production-ready Veo 3.1 prompts, scene by scene, with a permanently LOCKED page visual style. Activate ONLY when the user explicitly types "run story reel builder" or directly asks to run it. Do NOT auto-trigger on general video, prompt-writing, or Veo requests — explicit invocation only.
disable-model-invocation: true
---

# Story Reel Builder

A guided workflow for turning a strange-true-story script into multi-scene Veo 3.1 prompts. It works exactly like a scene-by-scene video director, but the page's visual style, aspect ratio, and audio are PERMANENTLY LOCKED and must never be asked about or changed. Era and atmosphere flex to fit each story; the locked look never does.

---

## LOCKED PAGE SETTINGS (never ask, never change)

**FIRST: read `reference-style.md` in this skill folder before writing any prompt.** It holds
the full style block and the two gold-standard example prompts. Every prompt you emit must
match that richness and density — not a short label. The richness lives in the words.

Apply these to every single scene prompt automatically:

- **Visual style (LOCKED):** Raw, realistic documentary footage look — authentic and unpolished, never glossy or over-rendered. Rich, vivid, natural color that feels alive (never washed out, never drained to grey). Strong atmospheric depth — soft haze and layered distance that draws the eye in and creates intrigue. Fine natural film grain in every frame. Shallow depth of field isolating the subject. Immersive, curious mood by default.
- **Color (LOCKED):** Rich, vivid, natural color — full and alive, not tinted to any single scheme. Color richness must HOLD even in dim, interior, candlelit, or night scenes — those scenes keep deep glowing color and never drain to flat grey. This is non-negotiable: scene lighting may be dark, but the color stays rich.
- **Darkness (CONTROLLED, situational):** The default mood is curious and immersive, NOT gloomy. Add darkness only when a specific story beat turns dark, and only a little — deeper shadows and a faint sense of unease. Darkness never overrides the rich colorful base.
- **Aspect ratio (LOCKED):** 9:16 vertical, always.
- **Audio (LOCKED):** Raw ambient/environmental sound ONLY, matched to the scene (wind, footsteps, room tone, distant sounds). NEVER music. NEVER spoken dialogue or narration in the video — the user adds narration separately, so no voice is ever written into the Veo prompt.

### What FLEXES per story
- **Era & setting:** match the story's time period precisely (e.g. a 1732 scene looks period-accurate to 1732, a 1960s scene looks 1960s) — while still obeying the locked style and color above.
- **Atmosphere:** the emotional weather of each scene (eerie, somber, tense, still) adapts to the story beat.

---

## ACTIVATION

Run only when explicitly invoked ("run story reel builder"). On activation, check what the user provided:
- **A ready-made scene breakdown** (e.g. from the story-reel-writer skill) → restate it and go to Stage 1 confirmation.
- **A finished narrator script with no scenes** → split it into scenes yourself first (≈1 scene per 6 seconds of narration, minimum 5 scenes per 30s), then present that breakdown for confirmation in Stage 1.
- **Nothing yet** → ask the user to paste the story script or scene breakdown.

Do not begin emitting Veo prompts until the scene breakdown is confirmed.

---

## HOW TO RUN — interview discipline (follow strictly)

1. **Ask in grouped rounds, one round per scene.** Present a scene's questions together, then STOP and wait. Never drip one question at a time.
2. **Propose, don't interrogate.** Infer what you can from the script and propose it for confirmation.
3. **Escape hatch.** End every question round with: *"Or say 'defaults' and I'll make strong choices for the rest."*
4. **Locked settings are never questioned.** Never ask about style, color, aspect ratio, or audio — they are locked above. Only ask about per-scene specifics (mode, frames, camera, action).
5. **One action per shot. Name one light source. Plain visual language.** Always.

---

## STAGE 1 — Confirm the scene breakdown

Present the scenes as a numbered list, one line each, with the era/setting noted per scene:

```
Scene N — [one-line what happens] · [era/setting]
```

Ask: "Here's the scene breakdown. Adjust the count, order, or content — or confirm and we'll build them one by one." Wait. Lock the confirmed breakdown.

---

## STAGE 2 — Build a scene (one at a time)

When the user picks a scene to build, ask this grouped round:

- **Mode:** plain text-to-video · image-to-video (animate one source image) · first-and-last-frame (bridge a start and end image) · ingredients-to-video (reference images for consistency)?
- **Starting frame:** supplying an image, or want a first-frame (or first-and-last-frame) image prompt generated?
- **This scene's specifics:** camera (shot / angle / movement), the single main action. (Audio is locked to ambient-only — do not ask.)

End with the escape-hatch line. Wait. Then emit the prompt(s) per the mode rules, applying ALL locked settings and the scene's era.

### Mode rules
- **text-to-video** — full labeled prompt (all fields).
- **image-to-video** — the image supplies the scene. Output ONLY camera movement, the added action, and ambient audio. Do not re-describe what's in the image (re-describing causes morphing). Omit Subject and Context.
- **first-and-last-frame** — output three blocks: a Start-frame image description, an End-frame image description, and the Veo bridge prompt describing the transition + ambient audio.
- **ingredients-to-video** — reference supplied images by role ("using the provided setting…"). Omit fields the references already supply.
- **multi-beat in one clip** — timestamped segments (~2s each), camera + action + ambient per segment, total ≤ 8s.

---

## REFERENCE-IMAGE PROMPTS (on request)

When the user asks for a first frame, last frame, or reference image prompt, emit an image-generation prompt (for Nano Banana / Gemini image). Every image prompt MUST embed the locked style and the scene's era:

```
[FRAME] [era-accurate scene description], raw realistic documentary footage look, rich
vivid natural color that holds even in dim light, strong atmospheric depth and soft haze,
fine film grain, shallow depth of field, immersive curious mood, 9:16 vertical. Absolutely
no text, no captions, no words, no letters, no title cards anywhere in the image.
```

For first-and-last-frame, the start and end descriptions must keep identical style, color, lighting, and setting so only the described change differs (prevents drift/morphing).

**NO-TEXT RULE (critical):** The user has had unwanted text burn into generated footage. Every image AND video prompt must explicitly forbid all on-screen text, captions, words, letters, numbers, and title cards — both in the prompt body and the negatives. Never describe signage, books, or labels with legible text.

---

## OUTPUT FORMAT (every Veo prompt)

Labeled fields, in this order. Omit fields the chosen image mode already supplies.

```
Cinematography: shot + angle + movement + lens
Subject: focal character/object, specific, era-accurate
Action: one present-tense action
Context: location, time period, the one light source, props (era-accurate)
Style: LOCKED — raw realistic documentary footage, rich vivid natural color (holds even
       in dim/night scenes), strong atmospheric depth, fine film grain, shallow depth,
       immersive curious mood; add slight darkness ONLY if the story beat is dark
Audio: ambient/environmental sound only, specific to the scene. Always include "no music,
       no dialogue, no narration."
Negative: ALL on-screen text, subtitles, captions, title cards, watermark, logo, words,
       letters, numbers, signage text, overlays, distorted hands, extra fingers, extra
       limbs, deformed faces, jittery motion, morphing, warping, duplicate subjects, blurry
       footage, compression artifacts, oversaturation, plastic CGI look, glossy render,
       music, spoken voice, modern objects in historical scenes
Technical: 9:16, [4/6/8s], [720p/1080p]
```

---

## PRODUCTION RULES (apply to all prompts)

- **5-part backbone:** Cinematography + Subject + Action + Context + Style.
- **One main action per shot** — concurrent actions fragment the result.
- **Name one light source** in Context — stabilizes the look, kills plastic-CGI appearance.
- **Raw footage, not glossy** — every prompt aims for authentic, unpolished, real documentary footage. Avoid "cinematic," "glossy," "rendered" language; favor "raw, real, natural, documentary."
- **Color must stay rich** — even in dark/interior/night scenes the color stays vivid and alive, never draining to flat grey.
- **Inject FULL richness, not a label** — write the style out densely in every prompt (name the specific rich tones present in this scene, the haze, the light source, the grain). A short style label produces flat, generic images. Match the density of the gold-standard examples in `reference-style.md`.
- **Force atmosphere on DAYTIME scenes** — bright outdoor scenes (pitch, stadium, street at noon) render flat and generic unless you explicitly add "soft atmospheric haze, hazy layered depth, light catching in the air, rich saturated natural color, fine film grain." Never let a daytime scene go clean and flat.
- **No on-screen text, ever** — forbid all text/captions/words/letters in both prompt body and negatives.
- **Audio is always ambient-only** — specify the real environmental sound; always append "no music, no dialogue, no narration."
- **Era accuracy** — every subject, prop, costume, vehicle, and setting must match the story's period. Add "modern objects" to negatives for historical scenes.
- **Negatives as descriptive nouns** (`wall, frame`), never instructions (`no walls`).
- **Consistency:** reuse identical style wording across every scene (it's locked); reuse the same 1–3 reference images for recurring characters/objects; 9:16 for the whole project; anchor recurring subjects on unchanging details.
- **Constraints:** durations 4 / 6 / 8s only; 720p to iterate, 1080p final; prompt under 2000 characters; avoid legible on-screen text (Veo renders it poorly).
- **Camera language is explicit** — shot type, angle, movement, lens. No vague words like "cinematic" in the camera field (the look is already locked in Style).

---

## CLOSING A SESSION

When scenes are built, give a short recap: the locked settings (one line), the list of built scenes, and which reference images the user still needs to generate. The prompts are the deliverable — no padding.
