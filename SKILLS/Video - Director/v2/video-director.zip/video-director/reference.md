# Veo 3.1 — Reference Guide

The knowledge base. You read this to understand and direct Veo, and to debug output when the Director skill drifts. General cinematic — any subject, any genre, 16:9 or 9:16.

**Conventions used throughout:**
- Camera direction uses standard cinematographic language — shot type, angle, movement, lens.
- Dialogue is written as `Character says: "line."` with a tone note.
- Unwanted on-screen text is prevented by listing `subtitles, captions, text overlays` in the negative block.
- Negative prompts are written as descriptive nouns (`wall, frame`), never as instructions (`no walls`).
- Every prompt is output in the labeled format (§10).

---

## 1. Technical Specs & Known Limitations

| Parameter | Value | Note |
|---|---|---|
| Duration | 4, 6, or 8s | 4–6s for motion-heavy action; 8s for still/atmospheric |
| Resolution | 720p / 1080p | 720p to iterate, 1080p for finals |
| Aspect ratio | 16:9 / 9:16 | Lock for the whole project; don't flip mid-sequence |
| Frame rate | 24fps | Standard cinematic |
| Audio | Native | Dialogue, SFX, ambient — generated from text |
| Reference images | Up to 3 | Character / object / style |
| Prompt length | ≤ 2000 chars | Stay under it |
| Watermark | SynthID on all output | — |

**Known weak spots — design around these:**
- Complex multi-action scenes fragment → **one main action per shot.**
- Identity drifts across shots without consistent references.
- Lip-sync is not exact → plan VO alignment in post if precision matters.
- Hands/fingers and small details distort in busy scenes.
- Legible on-screen text renders poorly → avoid it or use "stylized unreadable text."

---

## 2. The 5-Part Formula

```
Cinematography + Subject + Action + Context + Style & Ambiance
```

- **Cinematography** — shot type + angle + movement + lens.
- **Subject** — the focal character/object, specific (10+ attributes when it's a person).
- **Action** — ONE present-tense action; micro-motion beats spectacle.
- **Context** — location, time, weather, one named light source, sparse props.
- **Style & Ambiance** — aesthetic, color grade, film stock, mood.

**Worked example:**
> Medium shot, slight low angle, slow dolly-in. A weary detective in his 50s, loosened tie, rubbing his temples, leaning back in a creaking chair as rain streaks the window. Cluttered 1980s office at night, lit by a single desk lamp and the green glow of a CRT monitor. Retro 35mm look, grainy, warm amber against cool window-blue.

---

## 3. Cinematography Vocabulary

**Angles**

| Angle | Effect |
|---|---|
| Eye-level | Neutral, relatable |
| Low-angle | Powerful, imposing |
| High-angle | Vulnerable, small |
| Bird's-eye | Overview, map-like |
| Dutch angle | Unease, dynamism |

**Movement**

| Movement | Use |
|---|---|
| Static | Stillness, observation |
| Pan / tilt | Reveal across / up–down |
| Dolly | Push in (intimacy) / pull out (isolation) |
| Truck | Travel alongside a subject |
| Crane | Vertical sweep, scale reveal |
| Handheld | Realism, immediacy |
| Arc | Circle the subject |

**Shot composition**

| Shot | Framing | Use |
|---|---|---|
| EWS | Full environment | Establish location |
| WS | Full body + space | Context, scale |
| MS | Waist up | Dialogue, interaction |
| CU | Head & shoulders | Emotion |
| ECU | Eyes / detail | Intensity |

**Lens & focus:** shallow depth of field (isolate subject), deep focus (everything sharp), wide-angle (expansive, slight distortion), telephoto/macro (compression / detail), rack focus (shift attention), dolly-zoom (vertigo).

> Replace "cinematic" with actual choices: *"low-angle slow dolly-in, shallow depth of field"* tells Veo something; "cinematic" tells it nothing.

---

## 4. Subject & Consistency

Write the subject specifically and, across a series, **verbatim** — same wording every shot. Pair with 1–3 reference images (§6). Anchor on unchanging details (a jacket, a marking, a scar, a tag) — those are what the eye and the model track. Lock the aspect ratio across the project.

---

## 5. Audio

Define audio or Veo hallucinates it (wrong music, stray laughter, mismatched ambience).

- **Dialogue** — `Character says: "line."` plus tone. Keep to one breath (~12–15 words). One sentence per speaker; multi-character → name who speaks.
  > The detective says, in a weary voice: "Of all the offices in town, you walked into mine."
- **SFX** — distinct, specific: `SFX: thunder cracks in the distance.`
- **Ambient** — the background bed: `Ambient: quiet office hum, rain on glass.`
- If you want silence under one element: state `no background music` explicitly.

---

## 6. Reference Images — Three Distinct Modes

These all take images as input but behave completely differently. Conflating them is the top cause of wasted image-to-video generations.

**6a. Image-to-video** — one source image, animated. The image *is* the scene/first frame.
> **Rule:** do NOT re-describe what's already in the image. Describe only the *motion, camera move, and audio* to add. Re-describing makes text fight the image → morphing.
```
Example: "Slow push-in. The subject turns their head toward the window and exhales.
Ambient: soft room tone, distant traffic. no music."
```

**6b. Ingredients-to-video** — up to 3 reference images fed in to stay *consistent* across a new scene that isn't literally those images. Prompt by **role**, and always describe the subject's identity in words alongside the reference — the image *guides* generation, it does not clone, so references alone drift to a generic version. For a pixel-exact copy of a specific real subject, use image-to-video (6a) on the actual photo instead.
```
Example: "Using the provided character and the provided office setting, a medium shot of
the character sitting at the desk, looking up as the door opens."
```

**6c. First-and-last-frame** — a start image + an end image; Veo generates the bridge.
```
Start: subject standing at the door, hand on the handle.
End:   subject inside the lit room, door closed behind them.
Veo:   "Smooth 6-second transition as the subject steps through and the door closes."
```

---

## 7. Creating Reference Images (Role-Based)

The reference images in §6b are generated *upstream* (Gemini 2.5 Flash Image / Nano Banana, or any image model). How you prompt them decides whether Veo can lock onto them. **A busy, badly-lit reference is worthless regardless of the Veo prompt.**

**Lockability rules (apply to all roles):** plain seamless background, even consistent lighting, neutral framing, full visibility of identifying features. Reuse the *same* refs across the whole series.

| Role | Creation prompt shape |
|---|---|
| **Character** | Front-facing or 3/4 portrait of [character, full attributes], neutral expression, plain seamless [color] background, even soft studio lighting, [outfit] fully visible. Photorealistic, sharp. |
| **Object** | Isolated studio shot of [object] on a plain seamless background, even lighting, accurate detail, [angle]. |
| **Style** | A frame representative of [aesthetic: palette, grain, film stock, mood]. Subject secondary — the *look* is the point. |

**Two-step workflow:** generate the role refs → feed them into ingredients-to-video (§6b).

---

## 8. Negative Prompts

Descriptive nouns, never instructive ("wall, frame" — not "no walls"). Default block:

```
subtitles, captions, text overlays, watermark, logo, words on screen,
distorted hands, extra fingers, extra limbs, deformed faces,
jittery motion, morphing, warping, duplicate subjects,
blurry footage, low resolution, compression artifacts, oversaturation, plastic CGI look
```

Trim if it over-constrains (see §12).

---

## 9. Timestamp Prompting (multi-shot in one generation)

Direct several beats inside a single ≤8s generation. ~2s per beat, specify camera + action + audio per segment, hold the subject consistent.

```
[00:00-00:02] Medium shot, the explorer pushes aside a vine to reveal a path.
[00:02-00:04] Reverse shot on her face, awe. SFX: rustling leaves, bird calls.
[00:04-00:06] Tracking shot as she runs a hand over carved stone.
[00:06-00:08] High crane shot, she stands small in a vast ruin. SFX: soft orchestral swell.
```

---

## 10. Output Format (labeled — project canon)

Field order, every prompt:

```
Cinematography: shot + angle + movement + lens
Subject: focal character/object, specific
Action: one present-tense action
Context: location, time, light source, props
Style: aesthetic, color grade, mood
Audio: dialogue / SFX / ambient (+ "no music" if needed)
Negative: [default block, trimmed as needed]
Technical: aspect ratio, duration, resolution
```

In **image-to-video** and **ingredients** modes, **omit** the fields the image already supplies (Subject/Context) rather than printing them empty.

---

## 11. Clip Extension

Build longer sequences: generate your strongest 4–8s base clip → extend it → stitch in your NLE. Use first/last-frame control for smooth handoffs; keep prompt language consistent across extensions.

---

## 12. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Soft / smeared motion | Too many actions in one clip | Drop to 4s; one action; add reference image |
| Subject drifts between shots | Inconsistent references / wording | Reuse same refs; paste identical description |
| Reference ignored / subject regenerates different (e.g. younger) | Identity not described in text, or used ingredients (which regenerates) | Describe identity in words to match the ref; for an exact subject use image-to-video on the real photo; use a clean, well-lit, plain-background ref |
| Morphing in image-to-video | Re-described the scene | Describe only added motion/camera/audio |
| Distorted hands/fingers | Complex pose, weak negatives | Simplify pose; keep negative block; pull wider |
| Lighting jumps between clips | Prompt wording varies | Fix 2–3 lighting descriptors, reuse verbatim |
| Wrong / intrusive audio | Undefined audio | Specify ambient + SFX; add `no music` |
| Subtitles appear | — | Keep `subtitles, captions, text overlays` in negatives |
| Stuck in a bad "look" | Seed rut / over-constrained | Change seed; cut adjectives; move one variable |

**Practical rules:** one action per shot · name one light source · lock aspect ratio · plain language over poetry · move one variable at a time when iterating.

---

*This is the knowledge base. A companion director skill operationalizes everything here into a guided, multi-stage workflow.*
