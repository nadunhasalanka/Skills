---
name: video-director
description: Multi-stage interactive workflow that turns a video idea into structured, production-ready Veo 3.1 prompts, scene by scene. Activate ONLY when the user explicitly types "run video director" or directly asks to run the video director. Do NOT auto-trigger on general video, prompt-writing, or Veo requests — this runs on explicit invocation only.
disable-model-invocation: true
---

# Video Director

A guided workflow for building a multi-scene video as Veo 3.1 prompts. It interviews the user in grouped rounds, locks project-wide settings, breaks the idea into scenes, generates reference-image prompts on request, and emits final per-scene prompts in a fixed labeled format.

This skill is self-contained for normal operation — every rule needed to run is below. A companion file, `reference.md`, sits in this same folder with the full cinematography vocabulary tables, expanded mode examples, and the troubleshooting matrix. Read it when you need more depth than the rules below provide — for example, the user requests unusual camera work, or a generation keeps failing and you need the symptom→fix table.

---

## ACTIVATION

Run only when the user explicitly invokes it ("run video director"). On activation:
- If the user already gave a video idea, restate it in one line and go to Stage 1.
- If not, ask for the video idea/story, then go to Stage 1.

Do not begin generating prompts until the project settings (Stage 1) are locked.

---

## HOW TO RUN — interview discipline (follow strictly)

1. **Ask in grouped rounds, one round per stage.** Present all of a stage's questions together, then STOP and wait for the user's reply. Never drip one question at a time. Never proceed to the next stage with unanswered questions you invented answers for.
2. **Propose, don't interrogate.** Where you can infer an answer from the idea, state your proposal and ask the user to confirm or adjust, rather than asking cold.
3. **Always offer an escape hatch.** End every question round with: *"Or say 'defaults' and I'll make strong choices for the rest."* If the user says defaults, stop asking and proceed with smart cinematic choices.
4. **Lock and carry forward.** Once project settings (style, aspect ratio, mood, audio direction, recurring subjects) are set, apply them to every scene automatically — never make the user restate them.
5. **One action per shot. Name one light source. Plain visual language.** Always.

---

## STAGE 1 — Project intake

Read the idea. Propose a scene breakdown (a numbered list, one line each). Then ask this grouped round:

- **Scenes:** "I'd break this into N scenes: [list]. Keep, or change the count/order?"
- **Aspect ratio:** 16:9 or 9:16?
- **Style:** describe the look in words, OR say you have a style reference image to match.
- **Mood / genre:** the emotional tone.
- **Audio direction (whole video):** spoken dialogue or VO? music or none? language/accent/tone?

End with the escape-hatch line. Wait for answers. Then restate the locked **Project Settings** in a short block.

Then, **once per session only**, show this compact orientation legend so the user has shared vocabulary for the proposals to come. Keep it short, frame it as a reference ("quick legend — refer back anytime"), and do not require the user to study or quote it. Never show it more than once.

```
Quick legend (so the shot proposals make sense):
SHOT (how close):  wide = whole setting · medium = waist-up, action · close-up = face/emotion · extreme close-up = eyes/detail
ANGLE (where from): eye-level = neutral · low = makes subject powerful · high = makes subject small
MOVEMENT:          locked-off = camera still · slow push-in = builds intimacy/tension · pan/tilt = sweep across or up
LIGHT/MOOD:        soft warm = gentle · hard contrast = dramatic · backlit/golden = glowy, emotional · low-key = moody, shadowy
```

Then move to Stage 2.

---

## STAGE 2 — Scene breakdown

For every scene, propose its content in one pass (do not interview scene-by-scene yet):

```
Scene N — [one-line what happens]
  Beats: [beat 1] → [beat 2] → [beat 3]
  Likely shot: [shot/angle/movement]
```

Ask: "Adjust any scene's content or beats, or confirm and we'll build them." Wait. Lock the confirmed breakdown.

---

## STAGE 3 — Reference image prompts (on request)

When the user asks for reference images, emit **role-based image-generation prompts** (these create the reference images in a separate image model such as Gemini 2.5 Flash Image / Nano Banana — this step outputs prompts, not images).

For each needed role, output:

```
[CHARACTER] Front-facing or 3/4 portrait of [full attributes], neutral expression,
plain seamless [color] background, even soft studio lighting, [outfit] fully visible,
photorealistic, sharp.

[OBJECT] Isolated studio shot of [object] on a plain seamless background, even lighting,
accurate detail, [angle].

[STYLE] A frame representative of [palette, grain, film stock, mood]. The look is the point;
subject secondary.
```

Lockability rules to honor: plain backgrounds, even consistent lighting, neutral framing, full visibility of identifying features, and the SAME references reused across the whole project.

---

## STAGE 4 — Build a scene

When the user picks a scene to build, do NOT stack technical sub-questions. Follow this order:

1. **Orient.** Restate the scene's creative intent in one plain sentence so the user knows what this shot is doing emotionally.
2. **Ask only what you cannot decide** — the **mode**, because it depends on what assets the user has. State each option in plain words for THIS scene: text-to-video (generate from scratch), image-to-video (animate a photo they already have — best when they want *that exact* subject), first-and-last-frame (bridge a start and end image), ingredients-to-video (reuse reference images to keep a subject consistent in a new scene).
3. **Propose the shot yourself.** Offer the camera, the single action, and the audio as your recommendation, each with a short plain-language reason — e.g. "locked-off close-up (camera stays still so the light does the work)." Never ask the user to supply camera terms cold.
4. **Close with one line:** "Tweak anything, or say 'go' and I'll emit it." Plus the defaults escape.

Then emit the final prompt(s) per the mode rules below, applying the locked Project Settings and reusing identical subject/style wording for consistency.

### Mode rules

- **text-to-video** — full labeled prompt (all fields).
- **image-to-video** — the image supplies the scene. Output ONLY camera movement, the added action, and audio. Do not re-describe what is in the image (re-describing causes morphing). Omit Subject and Context fields.
- **first-and-last-frame** — output three blocks: a Start-frame image description, an End-frame image description, and the Veo bridge prompt describing the transition + audio.
- **ingredients-to-video** — point at the supplied images by role AND describe the subject's identity in words in the same prompt (e.g. "the cat from the reference — an elderly grey-muzzled tabby, thin frame, cloudy left eye, torn left ear — slowly turns its head"). The reference guides generation but does not clone it, so the identity text is what holds it from drifting. Keep the Subject field; only omit Context if a setting reference supplies it. For a pixel-exact match to a real subject, use image-to-video instead.
- **multi-beat in one clip** — use timestamped segments (~2s each), camera + action + audio per segment, total ≤ 8s.

---

## OUTPUT FORMAT (every Veo prompt)

Labeled fields, in this order. Omit fields the chosen image mode already supplies.

```
Cinematography: shot + angle + movement + lens
Subject: focal character/object, specific
Action: one present-tense action
Context: location, time, light source, props
Style: aesthetic, color grade, mood
Audio: dialogue / SFX / ambient (add "no music" when needed)
Negative: subtitles, captions, text overlays, watermark, logo, words on screen, distorted hands, extra fingers, extra limbs, deformed faces, jittery motion, morphing, warping, duplicate subjects, blurry footage, compression artifacts, oversaturation, plastic CGI look
Technical: [16:9 or 9:16], [4/6/8s], [720p/1080p]
```

Dialogue is written as `Character says: "line."` with a tone note. Keep dialogue to one breath (~12–15 words), one sentence per speaker.

---

## PRODUCTION RULES (apply to all prompts)

- **5-part backbone:** Cinematography + Subject + Action + Context + Style & Ambiance.
- **One main action per shot** — multiple concurrent actions fragment the result.
- **Name one light source** in Context — it stabilizes the look and kills the plastic-CGI appearance.
- **Define all audio** — undefined audio gets hallucinated (stray music, wrong ambience).
- **Negatives as descriptive nouns** (`wall, frame`), never instructions (`no walls`).
- **Consistency:** reuse identical subject and style wording across every scene; reuse the same 1–3 reference images for recurring characters/objects; lock the aspect ratio for the whole project; anchor recurring subjects on unchanging details (an outfit, a marking, a tag).
- **References need reinforcing text.** A reference image steers generation, it does not clone. In ingredients-to-video, always describe the subject's identity in words to match the reference (age, build, coloring, distinctive marks) — references alone drift to a generic version (e.g. an old subject regenerates younger). To reproduce a specific real subject exactly, animate its actual photo with image-to-video rather than regenerating it.
- **Constraints:** durations 4 / 6 / 8s only; resolution 720p (iterate) or 1080p (final); prompt under 2000 characters; avoid legible on-screen text (Veo renders it poorly).
- **Camera language is explicit** — shot type, angle, movement, lens. Replace vague words like "cinematic" with concrete choices.

---

## CLOSING A SESSION

When scenes are built, offer a short recap: the project settings, the list of built scenes, and which reference images the user still needs to generate. Do not pad with commentary — the prompts are the deliverable.
